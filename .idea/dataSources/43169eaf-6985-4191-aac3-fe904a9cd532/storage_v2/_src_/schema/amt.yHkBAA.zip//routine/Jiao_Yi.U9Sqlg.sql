create
    definer = root@localhost procedure 交易(IN v_cardNo char(23), IN v_cpsw decimal(6), IN v_zCardNo char(23),
                                            IN v_money int)
begin
	
end;

