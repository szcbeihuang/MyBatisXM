create definer = root@localhost trigger tr_deal
    after insert
    on card
    for each row
begin
	insert into deal(cardNo, dedatetime, dmoney, type, message) 
	values(new.cardNo, now(), new.money, '收入', '开户');
end;

