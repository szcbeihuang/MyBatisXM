create
    definer = root@localhost procedure kh(IN v_cpsw char(12), IN v_type char(4), IN v_money int, OUT idd char(23))
begin
	declare id char(23);
	if @dl_phone is null then
		select '账号未登陆';
		set idd = null;
	else
		if (select count(*) from card where phone=@dl_phone) >= 3 then
			select '开户失败, 可开户卡已达上限3';
			set idd = null;
		else
			set id = concat('6236 1000 ', year(curdate()), ' ', lpad(month(curdate()), 2, '0'), lpad(day(curdate()), 2, '0'), ' ', lpad(floor(rand() * 1000), 3, '0'));
			set idd=id;
			select concat('开户成功,卡号:', id);
			insert into card(cardNo, phone, cpsw, khdate, money, type)
			values(id, @dl_phone, v_cpsw, curdate(), v_money, v_type);
		end if;
	end if;
end;

