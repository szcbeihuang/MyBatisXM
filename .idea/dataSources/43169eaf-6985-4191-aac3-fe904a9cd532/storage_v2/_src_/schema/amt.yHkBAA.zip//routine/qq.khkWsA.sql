create
    definer = root@localhost procedure qq(IN v_cardNo char(23), IN v_cpsw decimal(6), IN v_money int)
begin
	declare flag int;
	declare exit handler for sqlexception
	if flag is null then select 'jebz'; end if;
	rollback;
	start transaction;
	if @dl_phone=null then
		select '账号未登陆';
		set flag = 1;
		rollback;
	end if;
	if not exists(select * from card where cardNo = v_cardNo and cpsw=v_cpsw) then
		select '银行卡号或密码错误';
		set flag = 1;
		rollback;
	end if;
	update card set money = money - v_money where cardNo = v_cardNo;
	insert into deal(cardNo, dedatetime, dmoney, type, message) 
	values(v_cardNo, now(), v_money, '支出', '取钱');
	commit;
end;

