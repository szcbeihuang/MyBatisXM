create
    definer = root@localhost procedure udl(IN v_phone decimal(11), IN v_upsw char(12))
begin
	if exists (select * from users where v_phone=phone and upsw = v_upsw) then
		select '登陆成功';
		set @dl_phone=v_phone;
	else
		select '登陆失败';
		set @dl_phone=null;
	end if;
end;

