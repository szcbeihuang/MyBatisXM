create
    definer = root@localhost procedure register(IN v_UID decimal(18), IN v_name char(6), IN v_phone decimal(11),
                                                IN v_uname char(6), IN v_upsw char(12), IN v_address char(6))
begin
	if exists (select * from users where UID = v_UID) then
		select 'UID已被注册';
	elseif exists (select * from users where phone=v_phone) then
		select '手机号已被注册';
	else
		insert into users values(v_UID, v_name, v_phone, v_uname, v_upsw, v_address);
		select '注册成功';
	end if;
end;

