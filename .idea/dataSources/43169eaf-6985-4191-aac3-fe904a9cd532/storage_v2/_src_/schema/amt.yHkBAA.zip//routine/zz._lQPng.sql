create
    definer = root@localhost procedure zz(IN v_cardNo char(23), IN v_cpsw decimal(6), IN v_money int,
                                          IN v_zCardNo char(23))
begin
	declare exit handler for sqlexception
	rollback;
	start transaction;
	if @dl_phone=null then
		select '账号未登陆';
		rollback;
	end if;
	if not exists(select * from card where cardNo = v_cardNo and cpsw=v_cpsw) then
		select '银行卡号或密码错误';
		rollback;
	end if;
	update card set money = money - v_money where cardNo = v_cardNo;
	update card set money = money + v_money where cardNo = v_zCardNo;
	insert into deal(cardNo, dedatetime, dmoney, type, message, toCardNo) 
	values(v_cardNo, now(), v_money, '支出', '转账', v_zCardNo);
	insert into deal(cardNo, dedatetime, dmoney, type, message, toCardNo) 
	values(v_zCardNo, now(), v_money, '收入', '转账', v_cardNo);
	commit;
end;

