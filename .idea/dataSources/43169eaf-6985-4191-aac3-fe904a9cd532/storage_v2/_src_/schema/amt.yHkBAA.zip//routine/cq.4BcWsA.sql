create
    definer = root@localhost procedure cq(IN v_cardNo char(23), IN v_cpsw decimal(6), IN v_money int)
begin
	declare exit handler for sqlexception
	rollback;
	start transaction;
	if @dl_phone=null then
		select '账号未登陆';
		rollback;
	end if;
	if not exists(select * from card where cardNo = v_cardNo and cpsw=v_cpsw) then
		select '银行卡号或密码错误';
		rollback;
	end if;
	update card set money = money + v_money where cardNo = v_cardNo;
	insert into deal(cardNo, dedatetime, dmoney, type, message) 
	values(v_cardNo, now(), v_money, '收入', '存钱');
	commit;
end;

