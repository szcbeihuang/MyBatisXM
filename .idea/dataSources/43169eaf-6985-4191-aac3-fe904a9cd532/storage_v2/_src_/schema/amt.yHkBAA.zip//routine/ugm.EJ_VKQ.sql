create
    definer = root@localhost procedure ugm(IN v_upsw char(12))
begin
	if @dl_phone=null then
		select '账号未登陆';
	else
		update users set upsw = v_upsw where phone=@dl_phone;
		select '修改成功';
	end if;
end;

