create
    definer = root@localhost procedure pro_2(IN v_idNumber varchar(128), IN v_bpassword varchar(128))
begin
	if exists (select * from buser where v_idNumber=idNumber and bpassword = v_bpassword) then
		select '恭喜你，登陆成功！';
		set @d_idNumber=v_idNumber;
	else
		select '登陆失败';
		set @d_idNumber=null;
	end if;
end;

