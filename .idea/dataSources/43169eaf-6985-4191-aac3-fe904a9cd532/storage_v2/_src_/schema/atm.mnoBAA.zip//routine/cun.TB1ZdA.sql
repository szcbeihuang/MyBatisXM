create
    definer = root@localhost procedure cun(IN v_cardNumber varchar(128), IN v_cpassword varchar(128), IN v_money double)
begin
	declare exit handler for sqlexception
	start transaction;
	if  /*not*/ exists(select * from card where cardNumber = v_cardNumber and cpassword=v_cpassword) 
	then  select '卡号或密码错误';
		rollback;
	end if;
	update card set money = money + v_money where cardNumber = v_cardNumber;
	insert into log(cardNumber, dealTime, money, type, comment) 
	values(v_cardNumber, now(), v_money, '存入', '存钱');
	commit;
end;

