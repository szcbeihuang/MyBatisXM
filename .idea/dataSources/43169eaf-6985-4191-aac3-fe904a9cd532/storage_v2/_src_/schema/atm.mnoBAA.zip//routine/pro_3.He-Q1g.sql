create
    definer = root@localhost procedure pro_3(IN v_bpassword varchar(128))
begin
	if @d_idNumber=null then
		select '账号未登陆';
	else
		update buser set bpassword = v_bpassword where idNumber=@d_idNumber;
		select '修改成功';
	end if;
end;

