create
    definer = root@localhost procedure register(IN v_idnumber decimal(18), IN v_password varchar(128),
                                                IN v_name varchar(128), IN v_phone decimal(11))
BEGIN
if EXISTS (SELECT * FROM buser WHERE v_idnumber=idNumber)
THEN SELECT '已存在用户';
else
INSERT INTO buser (idNumber,bpassword,bname,phone) VALUES(v_idnumber,v_password,v_name,v_phone);
SELECT '注册成功';
end if;
END;

