create
    definer = root@localhost procedure qu(IN v_cardNumber varchar(128), IN v_money double)
BEGIN
if  EXISTS (SELECT * FROM card WHERE v_cardNumber=cardNumber)
then SELECT '存在此卡';
ELSE if   EXISTS(SELECT * FROM card WHERE v_cardNumber=cardNumber and money-v_money>=1)
THEN SELECT '存款不足';
else update card set money = money-v_money where cardNumber = v_cardNumber;
	insert into log(cardNumber, dealTime, money, type, comment) 
	values(v_cardNumber, now(), v_money, '支出', '取钱');
END if;
END IF;
END;

