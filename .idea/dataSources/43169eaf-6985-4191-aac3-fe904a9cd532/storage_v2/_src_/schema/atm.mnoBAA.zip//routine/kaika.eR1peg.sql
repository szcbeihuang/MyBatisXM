create
    definer = root@localhost procedure kaika(IN v_cpassword varchar(128), IN v_type varchar(128), IN v_money double,
                                             OUT ide varchar(128))
begin
	declare id char(23);
		if (select count(*) from card where idNumber=@d_idNumber) >= 3 then
			select '卡已达上限';
			set ide = null;
		else
			set id = concat('6236 1000 ', year(curdate()), ' ', lpad(month(curdate()), 2, '0'), lpad(day(curdate()), 2, '0'), ' ', lpad(floor(rand() * 1000), 3, '0'));
			set ide=id;
			select concat('开卡成功,id为:', id);
			insert into card(cardNumber, idNumber, cpassword, startTime, money, type,status)
			values(ide, @d_idNumber, v_cpassword, curdate(), v_money, v_type,0);
		end if;
end;

