create
    definer = root@localhost procedure pro_1(IN v_bname varchar(128), IN v_idNumber varchar(128),
                                             IN v_bpassword varchar(128), IN v_phone decimal(11))
begin
	if  exists (select * from buser where v_idNumber=idNumber) 
	then select '存在';
	else 
		insert into buser(bname,idNumber,bpassword,phone) values(v_bname, v_idNumber, v_bpassword, v_phone);
		select '注册成功';
	end if;
end;

