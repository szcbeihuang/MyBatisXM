create
    definer = root@localhost procedure proc_stu()
BEGIN
SELECT studentno,sname,birthdate,phone
FROM student
WHERE phone like '137%';
END;

