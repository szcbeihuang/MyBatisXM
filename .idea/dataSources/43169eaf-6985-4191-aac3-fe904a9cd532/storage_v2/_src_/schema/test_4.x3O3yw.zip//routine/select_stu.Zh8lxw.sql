create
    definer = root@localhost procedure select_stu(IN s_no char(12))
BEGIN 
SELECT sname FROM student
WHERE studentNo = s_no;
end;

