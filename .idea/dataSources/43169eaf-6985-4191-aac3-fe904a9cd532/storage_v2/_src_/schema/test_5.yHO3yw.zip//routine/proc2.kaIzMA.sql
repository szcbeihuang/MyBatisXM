create
    definer = root@localhost procedure proc2(IN s_no char(12), OUT str varchar(50))
BEGIN
IF  EXISTS(SELECT * From student WHERE s_no=studentNo)
THEN  SET str= (SELECT sname From student WHERE s_no=studentNo);
ELSE 
SET str=CONCAT(s_no,'不存在');
END IF;
end;

