create
    definer = root@localhost procedure proc1(IN c_no char(12))
BEGIN 
SELECT cname FROM course
WHERE courseno = c_no;
end;

