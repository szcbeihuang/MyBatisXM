create
    definer = root@localhost procedure stu_age(IN s_no char(12), OUT str varchar(50))
BEGIN 
IF  EXISTS(SELECT * From student WHERE s_no=studentNo)
THEN  SET str= (SELECT YEAR(now())-YEAR(birthdate) From student WHERE s_no=studentNo);
ELSE 
SET str=CONCAT(s_no,'不存在');
END IF;
end;

