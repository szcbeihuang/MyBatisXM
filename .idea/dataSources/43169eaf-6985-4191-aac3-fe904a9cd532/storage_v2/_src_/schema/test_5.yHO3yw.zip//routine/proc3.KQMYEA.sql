create
    definer = root@localhost procedure proc3(IN v_sno char(12), IN v_sname char(8))
BEGIN
call proc2(v_sno,@sname);
IF (@sname is not NULL)
then
update student set  sname=v_sname WHERE sname=@sname;
ELSE 
SELECT CONCAT(v_sno,'不存在');
END IF;
END;

