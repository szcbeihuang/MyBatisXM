create
    definer = root@localhost procedure proc4(IN v_i int)
BEGIN
DECLARE i int;
SET i=1;
label: LOOP
	if(i<=v_i)
	THEN
	INSERT INTO test_5(info) VALUES(CONCAT('loop index',i));
	set i=i+1;
	ELSE
	LEAVE label;
	END IF; 
END LOOP ;
SELECT * FROM test_5;
SELECT count(*) FROM test_5;
END;

