create definer = root@localhost trigger TR1
    after insert
    on orders
    for each row
begin 
UPDATE  product SET pnum=pnum-new.onum WHERE pid=new.pid;
UPDATE  product set Totalsales=Totalsales+new.onum WHERE pid=new.pid;
end;

