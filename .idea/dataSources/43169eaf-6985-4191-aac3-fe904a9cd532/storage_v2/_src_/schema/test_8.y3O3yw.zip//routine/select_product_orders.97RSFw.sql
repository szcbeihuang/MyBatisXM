create
    definer = root@localhost procedure select_product_orders()
BEGIN
SELECT *FROM product;
SELECT *FROM orders;
END;

