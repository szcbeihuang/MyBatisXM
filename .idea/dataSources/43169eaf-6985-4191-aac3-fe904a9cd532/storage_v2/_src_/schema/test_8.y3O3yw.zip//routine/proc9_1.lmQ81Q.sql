create
    definer = root@localhost procedure proc9_1(IN v_pid int, IN pid2 int)
BEGIN 
UPDATE product SET pid=pid2 WHERE pid=v_pid;
CALL select_product_orders;
END;

