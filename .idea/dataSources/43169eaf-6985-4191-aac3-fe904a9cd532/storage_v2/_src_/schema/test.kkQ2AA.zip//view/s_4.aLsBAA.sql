create definer = root@localhost view s_4 as
select `test`.`score`.`courseno`    AS `courseno`,
       max(`test`.`score`.`final`)  AS `MAX(final)`,
       `test`.`student`.`studentNo` AS `studentNo`,
       `test`.`student`.`sname`     AS `sname`
from `test`.`student`
         join `test`.`score`
where (`test`.`student`.`studentNo` = `test`.`score`.`studentno`)
group by `test`.`score`.`courseno`;

-- comment on column s_4.courseno not supported: 课程号

-- comment on column s_4.maxfinal not supported: 期末成绩

-- comment on column s_4.studentNo not supported: 学号

-- comment on column s_4.sname not supported: 姓名

