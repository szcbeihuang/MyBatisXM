create definer = root@localhost view s_2 as
select `test`.`teacher`.`teacherno`  AS `teacherno`,
       `test`.`teacher`.`tname`      AS `tname`,
       `test`.`teacher`.`department` AS `department`
from `test`.`teacher`
where (`test`.`teacher`.`department` = '计数院');

-- comment on column s_2.teacherno not supported: 教师号

-- comment on column s_2.tname not supported: 教师姓名

-- comment on column s_2.department not supported: 部门

