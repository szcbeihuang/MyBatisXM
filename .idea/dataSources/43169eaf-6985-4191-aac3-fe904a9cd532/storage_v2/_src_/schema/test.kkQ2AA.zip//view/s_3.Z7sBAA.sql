create definer = root@localhost view s_3 as
select `test`.`student`.`studentNo` AS `studentNo`,
       `test`.`student`.`sname`     AS `sname`,
       `test`.`course`.`cname`      AS `cname`,
       `test`.`score`.`final`       AS `final`
from `test`.`student`
         join `test`.`course`
         join `test`.`score`
where ((`test`.`student`.`studentNo` = `test`.`score`.`studentno`) and
       (`test`.`score`.`courseno` = `test`.`course`.`courseno`));

-- comment on column s_3.studentNo not supported: 学号

-- comment on column s_3.sname not supported: 姓名

-- comment on column s_3.cname not supported: 课程名

-- comment on column s_3.final not supported: 期末成绩

