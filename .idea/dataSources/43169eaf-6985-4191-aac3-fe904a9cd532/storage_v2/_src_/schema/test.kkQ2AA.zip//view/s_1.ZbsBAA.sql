create definer = root@localhost view s_1 as
select `test`.`student`.`studentNo`      AS `studentNo`,
       `test`.`student`.`sname`          AS `sname`,
       `test`.`student`.`departmentname` AS `departmentname`
from `test`.`student`
where (`test`.`student`.`departmentname` = '计数院');

-- comment on column s_1.studentNo not supported: 学号

-- comment on column s_1.sname not supported: 姓名

-- comment on column s_1.departmentname not supported: 所在系名

