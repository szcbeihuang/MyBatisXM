create definer = root@localhost view s_6 as
select distinct `test`.`student`.`studentNo` AS `studentNo`, `test`.`student`.`sname` AS `sname`
from `test`.`teacher`
         join `test`.`teach_course`
         join `test`.`course`
         join `test`.`student`
         join `test`.`score`
where ((`test`.`teacher`.`teacherno` = `test`.`teach_course`.`teacherno`) and
       (`test`.`teach_course`.`courseno` = `test`.`course`.`courseno`) and
       (`test`.`student`.`studentNo` = `test`.`score`.`studentno`) and
       (`test`.`score`.`courseno` = `test`.`course`.`courseno`) and (`test`.`teacher`.`tname` = '苏超然') and
       (`test`.`course`.`cname` = 'C语言'));

-- comment on column s_6.studentNo not supported: 学号

-- comment on column s_6.sname not supported: 姓名

