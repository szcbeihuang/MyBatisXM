create definer = root@localhost view s_5 as
select `test`.`teacher`.`tname`          AS `tname`,
       `test`.`teacher`.`department`     AS `department`,
       `test`.`course`.`cname`           AS `cname`,
       `test`.`teach_course`.`teachtime` AS `teachtime`
from `test`.`teacher`
         join `test`.`teach_course`
         join `test`.`course`
where ((`test`.`teacher`.`teacherno` = `test`.`teach_course`.`teacherno`) and
       (`test`.`teach_course`.`courseno` = `test`.`course`.`courseno`));

-- comment on column s_5.tname not supported: 教师姓名

-- comment on column s_5.department not supported: 部门

-- comment on column s_5.cname not supported: 课程名

